//3. Randomly select 5 items for your wish list, verify if you see their entry in the wish list
package PepperFry;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
//3. Randomly select 5 items for your wish list, verify if you see their entry in the wish list
import org.openqa.selenium.support.ui.WebDriverWait;

public class WishList {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.pepperfry.com/");
		WebDriverWait wait = new WebDriverWait(driver, 20);
		driver.manage().window().maximize();
		// wait for login link to be visible
		WebElement login = driver.findElement(By.linkText("Login"));
		wait.until(ExpectedConditions.visibilityOf(login)); // explicit wait- dynamic wait/
		driver.findElement(By.linkText("Login")).click();
		// handle the ad iframe //input[starts-with(@id,'reportcombo')
		wait.until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
		// driver.findElement(By.xpath("//span[@class='wewidgeticon we_close
		// icon-large']")).click();
		Thread.sleep(1000);
		driver.switchTo().defaultContent();
		// fill in credentials
		driver.findElement(By.name("user[new]")).sendKeys("sk@demo.com");
		driver.findElement(By.name("password")).sendKeys("123456");
		driver.findElement(By.name("logSubmit")).click();
		Thread.sleep(1000);

		driver.findElement(By.xpath("//span[@class='hd-meta-dept']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Lamps & Lighting')]")).click();
		driver.findElement(By
				.xpath("//div[@class='container-fluid clp-looking-for-section']//div[1]//div[1]//div[1]//a[1]//img[1]"))
				.click();

		String Prod1 = driver.findElement(By.xpath("//div[@class='pf-col xs-12']//a[contains(text(),'Lepus Chrome Metal and Glass Wall Light')]")).getAttribute("title");
		System.out.println(Prod1);
		driver.findElement(By.xpath("//a[@id='clip_wishlist_1732880']")).click();
		Thread.sleep(1000);
		
		String Prod2 = driver.findElement(By.xpath("//a[contains(text(),'Harriot Black Metal and Glass Wall Light')]")).getText();
		System.out.println(Prod2);
		driver.findElement(By.xpath("//a[@id='clip_wishlist_1732867']")).click();
		Thread.sleep(1000);
		
		String Prod3 = driver.findElement(By.xpath("//div[@id='p_3_1_1732862']//a[contains(text(),'Janssen Black Metal and Glass Wall Light')]")).getText();
		System.out.println(Prod3);
		driver.findElement(By.xpath("//a[@id='clip_wishlist_1732862']")).click();
		Thread.sleep(1000);
		
		String Prod4 = driver.findElement(By.xpath("//div[@id='p_5_1_1732865']//a[contains(text(),'Janssen Gold Metal and Glass Wall Light')]")).getText();
		System.out.println(Prod4);
		driver.findElement(By.xpath("//a[@id='clip_wishlist_1732865']")).click();
		Thread.sleep(1000);
		
		String Prod5 = driver.findElement(By.xpath("//a[@id='clip_wishlist_1732864']")).getText();
		System.out.println(Prod5);
		driver.findElement(By.xpath("//a[@id='clip_wishlist_1732859']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/header[1]/div[3]/div[1]/div[2]/div[1]/div[2]/div[1]/div[3]/div[2]/a[1]")).click();

	}

}
