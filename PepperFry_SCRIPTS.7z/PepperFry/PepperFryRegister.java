package PepperFry;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PepperFryRegister {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver drv= new ChromeDriver();
		drv.get("https://www.pepperfry.com/");
		drv.manage().window().maximize();
		
		WebDriverWait wait = new WebDriverWait(drv, 20); //wait for register link to be visible WebElement login=driver.findElement(By.linkText("Login"));new WebDriverWait(drv, 20); //wait for login link to be visible WebElement login=driver.findElement(By.linkText("Login"));
		WebElement register=drv.findElement(By.linkText("Login"));
		wait.until(ExpectedConditions.visibilityOf(register)); 
	    drv.findElement(By.id("registerPopupLink")).click();
	    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
	    drv.switchTo().frame(drv.findElement(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
	    drv.findElement(By.id("webklipper-publisher-widget-container-notification-close-div")).click(); 
	    Thread.sleep(1000); drv.switchTo().defaultContent();
	    //fill in credentials

	    drv.findElement(By.xpath("//input[@name='email']")).sendKeys("geet12345@gmail.com");
	    drv.findElement(By.xpath("//input[@name='mobile']")).sendKeys("3871008329");
	    drv.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Geet");
	    drv.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Negi");
	    drv.findElement(By.xpath("//input[@name='password1']")).sendKeys("Geet@12345");
	    drv.findElement(By.xpath("//span[contains(text(),'Female')]")).click();
	    drv.findElement(By.xpath("//input[@name='register']")).click();
	    Thread.sleep(5000);
	    String winhandle= drv.getWindowHandle();
        drv.switchTo().window(winhandle);
        
    /*    for (String winhandle: driver.getWindowHandles()) {
            driver.switchTo().window(winhandle);
            System.out.println("Window Switch");        
            Thread.sleep(2000);
        }
        */

         drv.findElement(By.xpath("//div[@id='offerPopups']//a[@class='popup-close']")).click();
        
        Actions act=new Actions(drv);
        WebElement hoverLgnBl=drv.findElement(By.xpath("//li[@class='login-block']"));
        act.moveToElement(hoverLgnBl).perform();
        WebElement logoutLnk=drv.findElement(By.linkText("Logout"));
        act.moveToElement(logoutLnk).click().build().perform();
        Thread.sleep(1000);
        		
	}

}
