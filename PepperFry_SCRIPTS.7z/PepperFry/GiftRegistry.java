package PepperFry;

public class GiftRegistry {

}
