//Add three items in the cart to purchase, verify that the total cost of the cart is same as expected or not.
package PepperFry;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddItems {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.pepperfry.com/");
		WebDriverWait wait = new WebDriverWait(driver, 20);
		driver.manage().window().maximize();
		// wait for login link to be visible
		WebElement login = driver.findElement(By.linkText("Login"));
		wait.until(ExpectedConditions.visibilityOf(login)); // explicit wait- dynamic wait/
		driver.findElement(By.linkText("Login")).click();
		// handle the ad iframe //input[starts-with(@id,'reportcombo')
		wait.until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
		Thread.sleep(1000);

		driver.findElement(By.xpath("//span[@class='wewidgeticon we_close icon-large']")).click();
		Thread.sleep(1000);
		driver.switchTo().defaultContent();
		// fill in credentials
		driver.findElement(By.name("user[new]")).sendKeys("sk@demo.com");
		driver.findElement(By.name("password")).sendKeys("123456");
		driver.findElement(By.name("logSubmit")).click();
		Thread.sleep(1000);
		// wait.until(ExpectedConditions.presenceOfElementLocated(By.id("signinupPopupBox")));
		// driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//span[@class='hd-meta-dept']")).click();
		driver.findElement(By.xpath(" //a[contains(text(),'Three Seater Sofas')]")).click();
		driver.findElement(By.xpath(
				"//div[@id='p_1_1_1747332']//a[@class='clip-lstvw-add2cart-btn'][contains(text(),'Add To Cart')]"))
				.click();
		driver.switchTo().defaultContent();

		driver.findElement(By.xpath("//a[@class='gb-close pf-icon pf-icon-close']")).click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
		driver.findElement(By.xpath(
				"//div[@id='p_3_1_1747307']//a[@class='clip-lstvw-add2cart-btn'][contains(text(),'Add To Cart')]"))
				.click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
		driver.findElement(By.xpath("//a[@class='gb-close pf-icon pf-icon-close']")).click();
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
		Thread.sleep(1000);
		driver.findElement(By.xpath(
				"//div[@id='p_2_1_1747306']//a[@class='clip-lstvw-add2cart-btn'][contains(text(),'Add To Cart')]"))
				.click();
		List<WebElement> price = driver.findElements(By.className("oprice"));
		//int sum = 0;
		int num = 0;
		for (WebElement e : price) {
			// System.out.println(price);
			String cost = e.getText().toString();
			System.out.println(e.getText());
			String[] arr = cost.split("Offer Price Rs. ");
			System.out.println(arr[1]);
			num = Integer.parseInt(arr[1].replace(",", "")) + num;
			System.out.println("The total value of the products in cart is : " + num);
		}
		driver.quit();
	}

}
