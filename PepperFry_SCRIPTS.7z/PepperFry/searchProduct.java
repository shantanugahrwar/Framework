package PepperFry;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class searchProduct {
WebDriver driver;
String url;
Actions act;

@BeforeTest
public void beforeTest(){
System.setProperty("webdriver.chrome.driver","drivers\\chromedriver.exe");
driver=new ChromeDriver();
driver.manage().window().maximize();
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);//global timeout. 
act=new Actions(driver);
}

@Test
public void atTest() throws Exception{
driver.get("https://www.pepperfry.com/ <https://apc01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.pepperfry.com%2F&data=02%7C01%7Cgeetanjali.negi%40tavant.com%7C85c970a0597a4b50024a08d70443846c%7Cc6c1e9da5d0c4f8f9a023c67206efbd6%7C0%7C0%7C636982560362374237&sdata=tQpMnuJ10aBmmpCHLGHTlbRPiQcA5%2FyWgBJtUjAieDw%3D&reserved=0> "); 
WebDriverWait wait = new WebDriverWait(driver, 20); //handle the ad iframe //input[starts-with(@id,'data') wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
/*driver.switchTo().frame(driver.findElement(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
driver.findElement(By.xpath("//span[@class='wewidgeticon we_close icon-large']")).click(); 
Thread.sleep(1000); driver.switchTo().defaultContent();*/
//wait for login link to be visible
Thread.sleep(1000);
//Searching Departments -> Wall Art -> Floral 
WebElement dept=driver.findElement(By.className("hd-meta-dept"));
dept.click();
WebElement wallart=driver.findElement(By.linkText("Wall Art")); act.moveToElement(wallart).perform();
WebElement floral = driver.findElement(By.linkText("Floral"));
act.moveToElement(floral).click().build().perform();
wait = new WebDriverWait(driver, 20);
wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
driver.switchTo().frame(driver.findElement(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
driver.findElement(By.xpath("//span[@class='wewidgeticon we_close icon-large']")).click(); 
Thread.sleep(1000); driver.switchTo().defaultContent();

//Scroll Page down - do get away from the Chatwithus window. 
JavascriptExecutor js = (JavascriptExecutor) driver; js.executeScript("window.scrollBy(0,1000)");
//handle the login popup which comes
wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("signinupPopupBox"))));
//Pressing Escape button to remove the overlay div Robot r = new Robot(); r.keyPress(KeyEvent.VK_ESCAPE); r.keyRelease(KeyEvent.VK_ESCAPE); Thread.sleep(2000); driver.findElement(By.className("drpdwn-price-htol")).click();
driver.findElement(By.xpath("//*/ul[@id='sortBY']/li[3]/a")).click(); //sort by low to high //Fetching all the link elements which display product information 
List<WebElement> prodFloral=driver.findElements(By.xpath("//a[@class='clip-prd-dtl']"));
for(int i=0;i<5;i++) {
System.out.println(prodFloral.get(i).getText());
}
}

@AfterTest
public void cleanUp(){
driver.close();
}

}

