package PepperFry;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddToCartPurchase {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver drv= new ChromeDriver();
		drv.get("https://www.pepperfry.com/");
		drv.manage().window().maximize();
		drv.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		//WebDriverWait wait = new WebDriverWait(drv, 10); //wait for login link to be visible
		
		Actions action = new Actions(drv);
		WebElement element = drv.findElement(By.xpath("//span[text()='Departments']"));
		action.moveToElement(element).perform();
		WebElement Decor = drv.findElement(By.partialLinkText("D�cor"));
		action.moveToElement(Decor).perform();
		Thread.sleep(5000);
		WebElement hanging = drv.findElement(By.partialLinkText("Hanging"));
		action.moveToElement(hanging).click().build().perform();
		Thread.sleep(7000);
		WebElement product1 = drv.findElement(By.xpath("//a[@class='clip-prd-dtl'][contains(text(),'Peony Intricately Carved Modular (Set of 10 Blocks')]"));
		action.moveToElement(product1).click().build().perform();
		Thread.sleep(5000);
		
		// Switch to new window opened
		 String winhandle= drv.getWindowHandle();
	        drv.switchTo().window(winhandle);
		
		/*
		Set<String> handles=drv.getWindowHandles();
		Object[] handleInfo=handles.toArray();
		for(int i=0;i<handleInfo.length;i++) {
			System.out.println(handleInfo[i]);
		}
		
		
		drv.switchTo().window((String) handleInfo[1]).close();
		Thread.sleep(1000);
		drv.switchTo().window((String) handleInfo[0]);
		*/
	        
		WebDriverWait wait = new WebDriverWait(drv, 20); //wait for login link to be visible
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
		drv.switchTo().frame(drv.findElement(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
		drv.findElement(By.xpath("//span[@class='wewidgeticon we_close icon-large']")).click();
		Thread.sleep(1000); drv.switchTo().defaultContent();
		
		WebElement AddtoCart = drv.findElement(By.xpath("//a[contains(text(),'ADD TO CART')]"));
		action.moveToElement(AddtoCart).click().perform();
		Thread.sleep(800);
		WebElement GoToCart = drv.findElement(By.xpath("//a[contains(text(),'GO TO CART')]"));
		action.moveToElement(GoToCart).click().perform();
		
		
		
	
	}

}
