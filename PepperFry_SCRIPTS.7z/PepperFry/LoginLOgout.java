package PepperFry;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginLOgout {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver drv= new ChromeDriver();
		drv.get("https://www.pepperfry.com/");
		drv.manage().window().maximize();
				
		WebDriverWait wait = new WebDriverWait(drv, 10); //wait for login link to be visible
		WebElement login=drv.findElement(By.linkText("Login"));
		wait.until(ExpectedConditions.visibilityOf(login)); //explicit wait- dynamic wait/ driver.findElement(By.linkText("Login")).click();
		//handle the ad iframe //input[starts-with(@id,'reportcombo')
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
		drv.switchTo().frame(drv.findElement(By.xpath("//iframe[starts-with(@name,'notification-frame-')]")));
		drv.findElement(By.xpath("//span[@class='wewidgeticon we_close icon-large']")).click();
		Thread.sleep(1000); drv.switchTo().defaultContent();
		//fill in credentials
		drv.findElement(By.name("user[new]")).sendKeys("abc@demo.com <mailto:abc@demo.com> ");
		drv.findElement(By.name("password")).sendKeys("demo@123");
		drv.findElement(By.name("logSubmit")).click();
		Thread.sleep(1000);
		Actions act=new Actions(drv);
		WebElement hoverLgnBl=drv.findElement(By.xpath("//li[@class='login-block']"));
		act.moveToElement(hoverLgnBl).perform();
		WebElement logoutLnk=drv.findElement(By.linkText("Logout"));
		act.moveToElement(logoutLnk).click().build().perform();
		Thread.sleep(1000);

	}

}
