package com.PageObjects;

import java.awt.Robot;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.Base.GenericUtil;

import utils.ExcelFileReader.ExcelReadWrite;
import utils.PropertyReader.PropertyReader;

public class GiftRegistryPage extends GenericUtil {
	private Logger log = Logger.getLogger(GiftRegistryPage.class.getName());

	ExcelReadWrite excelreader;

	By WhtMore = By.xpath("//div[@id='main_navigation_menu']/div/ul/li[3]/a");
	By GiftRegisterbannerlink = By.xpath(
			"//body/div[@id='page']/header/div[@class='container']/div[contains(@class,'header-ext-wrap')]/div[@class='headerMiddleNav']/div[@id='headerUserArea']/div[@class='pf-col sm-10 md-10 pf-right pf-margin-top']/div[@class='middle_right']/div[@id='main_navigation_menu']/div[@id='megamenu']/div[@id='nav_whats_more']/div[@class='hd-whats-more-cont']/div[@class='hd-whats-more-list']/a[3]/span[1]");
	By eventtypeClick = By.xpath("//span[@id='select2-crgrEventType-container']");
	By eventtypefilterinput = By.xpath("//input[@class='select2-search__field']");
	By CreateRegistry = By.xpath("//a[@class='gr-banner-create-btn font-16 pf-center']");
	By EventName = By.xpath("//input[@placeholder='John Weds Jane']");
	By EventDescription = By.name("eventDescription");
	By EventStartDateInput = By.xpath("//input[@class='crgr-event-date-ip  gr-inpt']");
	// Select Start Date
	By StrtdateWidget = By.id("grEventDateCalender");

	By StartDateProceedBtn = By.xpath("//a[@class='gr-date-popup-proceed-btn font-12 pf-bold-txt']");

	// Select End Date
	By EndDate = By.xpath("//input[@name='registryEndDate']");

	By enddateWidget = By.id("grEndDateCalender");

	By EndDateSelection = By.xpath(
			"//div[@id='grEndDatePopup']//a[contains(@class,'gr-date-popup-proceed-btn font-12 pf-bold-txt')][contains(text(),'SELECT')]");

	// driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
	By SaveContinuegift = By.xpath("//form[@class='cr-gr-form']/div[7]/div/a");

	By SaveContinueforMe = By.xpath("//form[@id='crgrForMeForm']//a[@id='crgr_submit']");

	By shipName = By.xpath("//form[@id='grAddAddrForm']//input[@placeholder='e.g Akshay Kumar']");

	By shipMobileNumber = By.xpath("//form[@id='grAddAddrForm']//input[contains(@placeholder,'9582025112')]");

	By shipPostCode = By.id("postcode");
	By shipAddress = By.name("addressAddShip");
	By shipCity = By.id("city");
	By shipState = By.id("selectGRState");
	By RegistrySubmit = By.xpath("//a[@id='grAddAddrsubmit']");
	By DetailsName = By.xpath("//div/input[@class='crgr-ow-name-ip inpt disabled']");
	By DetailsEmail = By.xpath("//div/input[@class='cr-gr-email-ip inpt disabled']");

	// if (driver.findElement(By.xpath("//div[@class='owr-gr-lp-success-wrap']")))
	By startDate = By.xpath("//input[@class='crgr-event-date-ip  gr-inpt']");
	By startday = By.xpath("//a[@class='ui-state-default ui-state-active']");
	By formeRadio = By.xpath("//input[@id='grOwTypeMe']");
	By MobileNumber = By.xpath("//input[@class='onlynumbers contactnumber cr-gr-mobile-ip inpt']");
	By PageTitleGiftRegistry = By.xpath(
			"//div[@class='ma-gr-container  pf-white']/h6[@class='ma-gr-heading font-16 pf-txt-greyblue-dark pf-bold-txt']");
	By upload = By.xpath("//input[@name='registryFile']");
	By SelectEventType = By.name("eventType");
	By AlertSuccess = By.xpath("owr-gr-lp-success-popup");
	By AlertSuccessMsg = By.xpath("//div[@class='owr-gr-lp-success-wrap']/h5");
	By AlertSuccessskip = By.xpath("//a[@class='owr-gr-lp-success-skip-btn']");
	By AlertAd = By.xpath("//iframe[starts-with(@id,'webklipper-publisher-widget-container-notification-frame')]");
	By Adclose = By.id("webklipper-publisher-widget-container-notification-close-div");

	public GiftRegistryPage EventSelection(int k) throws Exception {

		Robot robot = new Robot();
		int i = k;
		try {
			excelreader.setExcelFile(PropertyReader.getInstance().getexcelpath(),
					PropertyReader.getInstance().getGiftsheetname());

			waitPresence(eventtypeClick);
			Assert.assertEquals(getText(PageTitleGiftRegistry), "CREATE GIFT REGISTRY");
			// Thread.sleep(3000);
			// click(eventtypeClick);
			SelectbyValue(SelectEventType, excelreader.getCellData(i, 0));
			// setText(eventtypefilterinput,excelreader.getCellData(i,0));
			// robot.keyPress(KeyEvent.VK_ENTER);
			// robot.keyRelease(KeyEvent.VK_ENTER);
			// Thread.sleep(3000);
			setText(EventName, excelreader.getCellData(i, 1));
			waitVisibility(EventDescription);
			System.out.println("Event Type not Found" + excelreader.getCellData(i, 2));
			setText(EventDescription, excelreader.getCellData(i, 2));
			// Thread.sleep(3000);
			click(startDate);
			waitPresence(startday);
			// Thread.sleep(3000);
			System.out.println("Event Type not Found" + CurrentDay());
			if (Integer.parseInt(getText(startday)) == CurrentDay() + 1) {
				click(startday);
			}
			// click(StartProceedBtn);
			Thread.sleep(500);
			waitVisibility(StartDateProceedBtn);
			click(StartDateProceedBtn);
			waitPresence(EndDate);
			waitVisibility(EndDate);

			Thread.sleep(2000);
			click(EndDate);

			String str1 = Integer.toString(CurrentDay() + 1).trim();

			System.out.println(" checkdate " + str1);
			WebElement enddateWidget = driver.findElement(By.id("grEndDateCalender"));
			// Thread.sleep(3000);
			// WebElement enddatevalue =
			// driver.findElement(By.xpath("//div[@id='grEndDateCalender']//a[contains(@class,'ui-state-default
			// ui-state-active')][contains(text(),'"+str1+"']"));
			List<WebElement> columns2 = enddateWidget.findElements(By.tagName("td"));
			// Thread.sleep(3000);
			for (WebElement cell : columns2) {
				// Thread.sleep(500);
				System.out.println(" check " + cell.getText());
				if (cell.getText().trim().equals(str1)) {
					Thread.sleep(500);
					cell.click();
					break;
				}
				// Thread.sleep(1000);
				// enddatevalue.click();
			}
			// Thread.sleep(500);
			waitVisibility(EndDateSelection);

			click(EndDateSelection);
			waitPresence(upload);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", get(upload));
			Thread.sleep(2000);
			uploadFileWithRobot("D:\\C84A3F45.PNG");
			Thread.sleep(2000);
			waitPresence(SaveContinuegift);

			executor.executeScript("arguments[0].click();", get(SaveContinuegift));
			// click(SaveContinuegift);
		} catch (Exception e) {
			System.out.println("Event Type not Found" + e);
		}

		return this;
	}

	public GiftRegistryPage registryowner(String s) throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 350)", "");
		try {
			waitPresence(formeRadio);
			Thread.sleep(2000);
			Assert.assertEquals(true, isSelected(formeRadio), "Radio for me isselected");
			System.out.println("Radio for me isselected");
			Assert.assertEquals(GetAttributeValue(MobileNumber), s);
			System.out.println("Mobile Number matched");
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 350)", "");

		} catch (Exception e) {
			System.out.println("Radio for me" + e);
		}
		Thread.sleep(1000);
		waitVisibility(SaveContinueforMe);
		waitPresence(SaveContinueforMe);
		click(SaveContinueforMe);

		return this;
	}

	public GiftRegistryPage registryshipAddress(int k) throws Exception {
		int i = k;
		try {
			waitVisibility(shipName);
			Thread.sleep(2000);
			setText(shipName, excelreader.getCellData(i, 3));
			setText(shipMobileNumber, excelreader.getCellDataformate(i, 4));
			System.out.println("Shipping name" + excelreader.getCellData(i, 3));
			waitVisibility(shipPostCode);
			setText(shipPostCode, excelreader.getCellDataformate(i, 5));
			waitVisibility(shipAddress);
			setText(shipAddress, excelreader.getCellDataformate(i, 6));

			Thread.sleep(1000);
			// Assert.assertEquals(GetAttributeValue(shipCity),"Gautam Buddha Nagar");
			waitVisibility(RegistrySubmit);
			waitPresence(RegistrySubmit);
			click(RegistrySubmit);
			Thread.sleep(1000);
		} catch (Exception e) {
			System.out.println("shipping added" + e);

		}
		// driver.switchTo().defaultContent();
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(getText(AlertSuccessMsg), "Congratulations!");
		{
			System.out.println("Success");
			// Log.info("Gift registry successfully added for me for event type :"+
			// excelreader.getCellData(i,0));
		}
		try {
			switchToFrame(AlertAd);
			System.out.println("chk1");
			click(Adclose);
			Thread.sleep(500);
			driver.switchTo().defaultContent();

		} catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
		}

		waitVisibility(AlertSuccessskip);
		click(AlertSuccessskip);
		Thread.sleep(1000);
		// ((JavascriptExecutor)
		// driver).executeScript("window.scrollTo(document.body.scrollHeight, 0)");

		return this;
	}

	public GiftRegistryPage goToGiftRegistryPage() {

		try {
			if (isDisplayed(WhtMore)) {
				Thread.sleep(2000);
				click(WhtMore);
				waitVisibility(GiftRegisterbannerlink);
				click(GiftRegisterbannerlink);
				waitVisibility(CreateRegistry);
				click(CreateRegistry);

			}

			else {
				log.error("Element Not Found for gift registry");
			}

		} catch (Exception e) {
			System.out.println("Exception occurred");
			log.fatal(e.toString());
		}

		return new GiftRegistryPage();
	}

}
