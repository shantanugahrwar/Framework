package com.PageObjects;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.Base.GenericUtil;

import Tests.ProductAddToCartTest;


 
public class ProductAddToCart extends GenericUtil {
	private Logger log = Logger.getLogger(ProductAddToCartTest.class.getName());
	
	By BedsImglink = By.xpath("//div[@class='container hp-whats-popular-section']/div[@class='row']/div[1]/div[1]/div[1]/a[1]/img[1]");
    By cartitems = By.xpath("//div[@class='item_card_wrapper'][1]/div/div/div[2]/p[3]/span[2]");
    By cartlistclose = By.xpath("//a[@class='gb-close pf-icon pf-icon-close']");
    By ProceedBtn = By.xpath("//div[@class='minicart_footer']/a");
    By carticonlink = By.xpath("//div/a[@class='pf-icon pf-icon-cart2 header_tab cart']");
    By TotalPay = By.id("total_pay_coupon");
    By Trash = By.xpath("//form[@name='cart_form']/div[1]/div/div/div[3]/div/a[@class='trash']");
    By couponcode = By.xpath("//input[@name='coupon_code']");
    By couponApply = By.xpath("//*[contains(@class,'valid_coupon')]");//
    By TotalOfferPrice = By.xpath("//div[@id='offer_price']//span[@class='price-nmbr']");
    
     
      
    public ProductAddToCart AddToCart() throws Exception {
 	  // 	click(BedsImglink);
 	   		((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 350)", "");
 	   		String [] ProdAmt = new String[3];
 	   		String [] cprice = new String[3];
 	   		float TotalAddtoCart=0;
 	   		try{ 
 	   			Actions act = new Actions(driver);
 	   			for(int i=1,k=0;i<=3;i++,k++){
       //  Thread.sleep(3000); 
         		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='pf-col srchrslt-crd-10x11 srch-rslt-cards margin-bottom25 clipprods']["+i+"]/div/div[1]")));
         		act.moveToElement(driver.findElement(By.xpath("//div[@class='pf-col srchrslt-crd-10x11 srch-rslt-cards margin-bottom25 clipprods']["+i+"]/div/div[1]"))).build().perform();
        // System.out.println(li.get(i)+"["+i+"]/div/div[1]/div");
        // Thread.sleep(3000);
         		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='pf-col srchrslt-crd-10x11 srch-rslt-cards margin-bottom25 clipprods']["+i+"]/div/div[5]/div/span[1]")));
         		ProdAmt[k]= driver.findElement(By.xpath("//div[@class='pf-col srchrslt-crd-10x11 srch-rslt-cards margin-bottom25 clipprods']["+i+"]/div/div[5]/div/span[1]")).getText();
        // Thread.sleep(3000);
         		System.out.println("add to cart"+ProdAmt[k]);
         		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='pf-col srchrslt-crd-10x11 srch-rslt-cards margin-bottom25 clipprods']["+i+"]/div/div[1]/div/a")));
         		act.moveToElement(driver.findElement(By.xpath("//div[@class='pf-col srchrslt-crd-10x11 srch-rslt-cards margin-bottom25 clipprods']["+i+"]/div/div[1]/div/a"))).click().build().perform();
         		Thread.sleep(500);
         		//waitVisibility(cartitems);
         		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='item_card_wrapper']["+i+"]/div/div/div[2]/p[3]/span[2]")));
         		cprice[k] = driver.findElement(By.xpath("//div[@class='item_card_wrapper']["+i+"]/div/div/div[2]/p[3]/span[2]")).getText();
         		System.out.println("value in cart"+cprice[k]);
         		String newcprice = cprice[k].replaceAll("\\D+","").trim();
         		String newaddprice = ProdAmt[k].replaceAll("\\D+","").trim();
         		if(newcprice.equals(newaddprice)){
         			System.out.println("values matched"+newcprice+" "+newaddprice); 
         		}
         		
         		TotalAddtoCart=TotalAddtoCart+Float.parseFloat(newaddprice);
         		System.out.println("valid added total: "+TotalAddtoCart);
         		waitVisibility(cartlistclose);
         	//	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='gb-close pf-icon pf-icon-close']")));
         		click(cartlistclose);
         	//	driver.findElement(By.xpath("//a[@class='gb-close pf-icon pf-icon-close']")).click();
         		((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 350)", "");
         		Thread.sleep(500); 
         
         }
 	   			
         
     }
 	   	
        catch (Exception e)
        {
        	System.out.println("valid added"+e);
        }
 	   	CartPriceCompare(TotalAddtoCart);
 	   		
      return this;
     }
    
    public void CartPriceCompare(float totalpay) throws Exception {
 	((JavascriptExecutor) driver).executeScript("window.scrollTo(document.body.scrollHeight, 0)");
 	 waitVisibility(carticonlink);
 	 click(carticonlink);
 	 waitVisibility(ProceedBtn);
 	 click(ProceedBtn);
 	 Thread.sleep(500);
 	 waitPresence(couponcode);
 	 setText(couponcode,"RAIN");
 	 waitVisibility(couponApply);
 	 click(couponApply);
 	 waitVisibility(TotalOfferPrice);
 	 waitPresence(TotalOfferPrice);
 	// Thread.sleep(500);
 	 try {
 	String TotalOfferAmt = getText(TotalOfferPrice).replaceAll("\\D+","").trim();
 	 Float totaldisplayAmt = Float.parseFloat(TotalOfferAmt);
 	 
 	// Float CompareAmt = (totalpay*6/100)+totalpay;
 	// int integerValue = (int)Math.round(double a);
 	// long cmpAmt = (long)Math.round(CompareAmt);
 	 if(Math.round(totaldisplayAmt)== Math.round(totalpay)){
 		 System.out.println("pricematches"+Math.round(totaldisplayAmt)+"\t"+Math.round(totalpay)); 
 		 
 	 }
 	 else if(Math.round(totaldisplayAmt)!= Math.round(totalpay)){
 		 System.out.println("not matches actual & expected"+Math.round(totaldisplayAmt)+"\t"+Math.round(totalpay)); 
 		 
 	 }
    }
 	 	catch(Exception e){
 		 
 	 }
 	 
 	 
 	 
    }
    
    public void RemoveItems() throws Exception {
 	Thread.sleep(1000);
    List <WebElement> cartdetail = driver.findElements(By.xpath("//form[@name='cart_form']/div"));
    ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 200)", "");
    for (int i=cartdetail.size();i<=1;i--){
 	   waitVisibility(By.xpath("//form[@name='cart_form']/div["+i+"]/div/div/div[3]/div/a[@class='trash']"));
 	   waitPresence(By.xpath("//form[@name='cart_form']/div["+i+"]/div/div/div[3]/div/a[@class='trash']"));
 	   driver.findElement(By.xpath("//form[@name='cart_form']/div["+i+"]/div/div/div[3]/div/a[@class='trash']")).click();
 	   
    }
    
    
    }
    
    public ProductAddToCart goToProductSelectionPage() {
        try{
            if(isDisplayed(BedsImglink)){
            Thread.sleep(500);
            click(BedsImglink );
            }
             
        else{
           log.error("Element Not Found for ProductSelection");
            }
        
       }
            catch (Exception e) {
            System.out.println("Exception occurred");
            log.fatal(e.toString());
         } 

 

        return new ProductAddToCart();
        }

}
