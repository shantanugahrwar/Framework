package com.PageObjects;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.Base.GenericUtil;

import Tests.LoginTest;

public class Login extends GenericUtil {
	private static Logger log = Logger.getLogger(LoginTest.class.getName());

	/** Web Elements */
	By usernameID = By.name("user[new]");
	By passwordID = By.name("password");
	By loginSubmit = By.name("logSubmit");
	By AlertAd = By.xpath("//iframe[starts-with(@name,'notification-frame-')]");
	By Adclose = By.xpath("//span[@class='wewidgeticon we_close icon-large']");
	By LoginLnk = By.xpath("(//*[text()='Login'])[1]");

	/**
	 * Page Methods
	 * 
	 * @throws InterruptedException
	 */

	/** Page Methods */

	public void loginToApp(String username, String password) throws InterruptedException {
		waitVisibility(LoginLnk);
		click(LoginLnk);
		try {
			Thread.sleep(1000);
			if (isDisplayed(AlertAd)) {
				switchToFrame(AlertAd);
				click(Adclose);
				Thread.sleep(1000);
				driver.switchTo().defaultContent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		wait.until(ExpectedConditions.visibilityOfElementLocated(usernameID));
		driver.switchTo().defaultContent();

		Thread.sleep(1000);
		setText(usernameID, username);
		log.info("Entering the UserName");
		setText(passwordID, password);
		log.info("Entering the Password");
		click(loginSubmit);
		log.info("Clicking on Submit button");
		// return new HomePage();
	}

}
