package utils.PropertyReader;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;



public class PropertyReader {
	private static PropertyReader instance;
    private static String propertyFilePath = System.getProperty("C:\\Eclipse\\PepperFry_Framework\\src\\main\\java\\com\\config\\config.Properties");
    private static String url;
    private static String browser;
    private static String excelpath;
    private static String Giftsheet;
    private static String shipMobile;
 
    //Create a Singleton instance. We need only one instance of Property Manager.
    public static PropertyReader getInstance () {
        instance = new PropertyReader();
        instance.loadData();
        return instance;
    }
 
    //Get all configuration data and assign to related fields.
    private void loadData() {
        //Declare a properties object
        Properties prop = new Properties();
 
        //Read configuration.properties file
        try {
            prop.load(new FileInputStream(propertyFilePath));
            //prop.load(this.getClass().getClassLoader().getResourceAsStream("configuration.properties"));
        } catch (IOException e) {
            System.out.println("Configuration properties file cannot be found");
         //   Log.fatal("Error in opening property file");
        }
 
        //Get properties from configuration.properties
        url = prop.getProperty("url");
        browser = prop.getProperty("browser");
        excelpath = prop.getProperty("excelpath");
        Giftsheet = prop.getProperty("Giftsheet");
       //  wrongPassword = prop.getProperty("wrongPassword");
    }
 
    public String getURL () {
      return url;
    }
 
    public String getbrowser () {
        return browser;
    }
    
    public String getexcelpath () {
        return excelpath;
    }
    
    public String getGiftsheetname () {
        return Giftsheet;
    }
    public String getshipMobile(){
    	return shipMobile;
    }
    
}


