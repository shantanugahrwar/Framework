package Tests;

public class Tesing {

	int a;
	static int b;

	public void m1() {
		a = 1;
		b = 2;
	}

	public static void m2() {
		b = 2;
	}
}
