package Tests;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.testng.annotations.Test;

import com.Base.BaseClass;
import com.PageObjects.GiftRegistryPage;

import utils.ExtentReports.ExtentTestManager;
import utils.PropertyReader.PropertyReader;

public class GiftRegistryTest extends BaseClass {

	private Logger log = Logger.getLogger(GiftRegistryTest.class.getName());
	GiftRegistryPage giftregister = new GiftRegistryPage();

	@Test(priority = 1, description = "Go to gift registrypage")
	public void GiftRegistryTest(Method method) throws Exception {

		ExtentTestManager.startTest(method.getName(), "gift registry scenarios");
		log.info("Trying to login in application");
		LoginTest.loginToApplication();

		for (int i = 1; i <= 5; i++) {
			log.info("looping through gift registry");
			int k = i;
			giftregister.goToGiftRegistryPage();
			giftregister.EventSelection(k).registryowner(PropertyReader.getInstance().getshipMobile())
					.registryshipAddress(k);
			k++;
		}

	}
}
