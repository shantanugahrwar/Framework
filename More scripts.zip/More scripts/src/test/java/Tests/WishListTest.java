 package Tests;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.testng.annotations.Test;

import com.Base.BaseClass;
import com.PageObjects.WishList;

import utils.ExtentReports.ExtentTestManager;

public class WishListTest extends BaseClass {
	WishList wishlist = new WishList();
	private Logger log = Logger.getLogger(WishListTest.class.getName());

	@Test(enabled = true )
	public void addToWishList(Method method) throws Exception {
		ExtentTestManager.startTest(method.getName(),"Add 5 products in wish list and verify the added products from wish list.");
		log.info("Trying to login in application");
		LoginTest.loginToApplication();
		log.info("Trying to remove product from wish list if already added");
		wishlist.removeWishList();
		log.info("Already added products are successfully removed");
		driver.get(driver.getCurrentUrl());
		log.info("Trying to add 5  products to wish list");
		wishlist.AddToWishList(prop.getProperty("itemtype"));
		log.info("new products are successfully added");
		driver.get(driver.getCurrentUrl());
		log.info("Trying to validate the products added in the wish list ");
		wishlist.validateWishList();
		log.info("Validation successfull: Wish list products same as added ones");

	}

}
