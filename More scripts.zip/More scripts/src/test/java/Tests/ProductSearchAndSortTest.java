 package Tests;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;

import org.testng.annotations.Test;


import com.Base.BaseClass;

import com.PageObjects.ProductSearchAndSort;

import utils.ExtentReports.ExtentTestManager;


public class ProductSearchAndSortTest extends BaseClass {
	
	private Logger log = Logger.getLogger(ProductSearchAndSortTest.class.getName());
	
 
	
		@Test(priority = 1, description = "Product Sort and write in excel")
    public void ProductSortTest(Method method) throws Exception {
    	
        ExtentTestManager.startTest(method.getName(), "Product Sorting Scenarios");
        log.info("Trying to login in application");
		LoginTest.loginToApplication();
		ProductSearchAndSort productsort=new ProductSearchAndSort();
		productsort.productSorting("Wall Art","Wild life","WallArt_Wildlife");
		productsort.productSorting("Furniture","Sofa Sets","Furniture_Sofa Sets");
		productsort.productSorting("Wall Art","Floral","WallArt_Floral");
	}


}
