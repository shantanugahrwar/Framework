 package com.Base;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.PageObjects.Login;

public class GenericUtil extends BaseClass {

	private static Logger log = Logger.getLogger(GenericUtil.class.getName());

	// Click Method
	public void click(By elementLocation) {
		driver.findElement(elementLocation).click();
	}

	// Write Text
	public void setText(By elementLocation, String text) {
		driver.findElement(elementLocation).sendKeys(text);
	}

	// Read Text
	public String getText(By elementLocation) {
		return driver.findElement(elementLocation).getText();
	}
	
	   public WebElement getElement(String s){
	        return driver.findElement(By.linkText(s));
	    }
	    
	    public WebElement get(By elementLocation) {
	        return driver.findElement(elementLocation);
	    }

	// Wait
	public void waitVisibility(By by) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}

	public boolean isDisplayed(By by) {
		waitVisibility(by);
		// wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		driver.findElement(by).isDisplayed();
		return true;

	}
	
	public void uploadFileWithRobot (String imagePath) {
        StringSelection stringSelection = new StringSelection(imagePath);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, null);
 
        Robot robot = null;
 
        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }
 
        robot.delay(250);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.delay(150);
        robot.keyRelease(KeyEvent.VK_ENTER);
    }


	public void waitPresence(By by) {
		wait.until(ExpectedConditions.presenceOfElementLocated(by));
	}

	public void switchToFrame(By by) {
		driver.switchTo().frame(driver.findElement(by));
	}

	public void moveToelement(By elementlocation) {
		Actions builder = new Actions(driver);
		builder.moveToElement(driver.findElement(elementlocation)).perform();

	}

	public void SelectbyIndex(By by, int i) {
		Select eventtype = new Select(driver.findElement(by));
		eventtype.selectByIndex(i);
	}

	public void SelectbyValue(By by, String s) {
		Select eventtype = new Select(driver.findElement(by));
		eventtype.selectByValue(s);
	}

	public int CurrentDay (){
		   Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
		      //getTime() returns the current date in default time zone
		      Date date = calendar.getTime();
		      int day = calendar.get(Calendar.DATE);
		      return day;
		}
	   
	   public boolean isSelected(By by){
		   if(driver.findElement(by).isSelected()){
			   return true;
		   }
		   else{
			   return false;
		   }
		}
	   
	   public String GetAttributeValue(By by){
		   return (driver.findElement(by).getAttribute("value"));
		}
	   
	

	}


