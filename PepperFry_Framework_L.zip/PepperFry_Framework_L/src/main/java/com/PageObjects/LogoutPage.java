package com.PageObjects;

import org.openqa.selenium.By;

public class LogoutPage {

	/**Web Elements*/
    By hoverLgnBtn=By.xpath("//li[@class='login-block']");
    By logoutLnk=By.linkText("Logout");
}
