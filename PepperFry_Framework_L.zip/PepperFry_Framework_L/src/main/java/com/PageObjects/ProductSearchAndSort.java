  package com.PageObjects;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.Base.GenericUtil;


import utils.ExcelFileReader.ExcelReadWrite;


public class ProductSearchAndSort extends GenericUtil {
	private Logger log = Logger.getLogger(ProductSearchAndSort.class.getName());
	
		
	
	/**Web Elements*/
    By heading1 = By.className("hd-meta-dept");//("//span[@class='hd-meta-dept']");
    
    By sort=By.className("drpdwn-price-htol"); //("//*[@id=\\\"curSortType\\\"]");
    By price=By.xpath("//*/ul[@id='sortBY']/li[3]/a");
    By AlertAd=By.xpath("//iframe[starts-with(@id,'webklipper-publisher-widget-container-notification-frame')]");
    By Adclose=By.id("webklipper-publisher-widget-container-notification-close-div");
    
    
    Actions action=new Actions(driver);
    ExcelReadWrite write=new ExcelReadWrite();
    
	public void productSorting(String s1,String s2,String sheetname) throws InterruptedException {
		try{
			waitVisibility(heading1);
			waitPresence(heading1);}
		catch(Exception e){
			System.out.println("Departments not found");
			log.info("Dpartments not found");
			log.error("Error"+e);
		}
		Thread.sleep(1000);
		click(heading1);
		//moveToElement(heading1);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(s1)));
	//	waitVisibility(heading2);
		action.moveToElement(getElement(s1)).perform();
		//moveToElement(heading2);
		Thread.sleep(1000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(s2)));
		//waitVisibility(heading3);
		action.moveToElement(getElement(s2)).click().build().perform();
		Thread.sleep(1000);  
		//if alert comes move back to default content
		//Scroll Page down - do get away from the Chatwithus window. 
		try {
			   switchToFrame(AlertAd);
				System.out.println("chk1");
	    		click(Adclose);
	    		Thread.sleep(500);
	    		driver.switchTo().defaultContent();
	    		
			} catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
			}
		try {
			waitVisibility(sort);
			click(sort);
			waitVisibility(price);
			click(price);
			Thread.sleep(500);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		System.out.println("Total Product = "+ driver.findElements(By.xpath("//div[@id='productView']/div/div/div/div")).size() + "\n");
		Map<String, Object[]> data = new TreeMap<String, Object[]>(); 
		List<WebElement> prodName=driver.findElements(By.xpath("//a[@class='clip-prd-dtl']"));
		List<WebElement> prodPrice=driver.findElements(By.xpath("//span[contains(@class,'clip-offr-price')]"));
		List<WebElement> prodSofa = driver.findElements(By.xpath("//div[@class='clip-lstvw-prdcnt']"));
		////span[contains(@class,'clip-offr-price')] //clip-offr-price 
		//write.saveFile();
		for(int i=0;i<5;i++) {
		if(s1.equalsIgnoreCase("Furniture")){
			data.put(Integer.toString(i), new Object[]{prodSofa.get(i).getText(),prodPrice.get(i).getText()}); 
			for (Map.Entry<String, Object[]> entry : data.entrySet()) {
			    System.out.println(entry.getKey() + "Namew:" + entry.getValue()[0]);
			    System.out.println(entry.getKey() + "Price:" + entry.getValue()[1]);
		}
		}
		else{
		data.put(Integer.toString(i), new Object[]{prodName.get(i).getText(),prodPrice.get(i).getText()}); 
		for (Map.Entry<String, Object[]> entry : data.entrySet()) {

		    System.out.println(entry.getKey() + "Namew:" + entry.getValue()[0]);
		    System.out.println(entry.getKey() + "Price:" + entry.getValue()[1]);
	
		}
		}
		}
		try {
			write.writeExcelData(data,sheetname);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*System.out.println(prodName.get(i).getText());
		System.out.println(prodPrice.get(i).getText());
		write.writeData(prodName.get(i).getText(), i, i);
		write.writeData(prodPrice.get(i).getText(), i, i+1);*/
		}
		//write.saveFile()

}
