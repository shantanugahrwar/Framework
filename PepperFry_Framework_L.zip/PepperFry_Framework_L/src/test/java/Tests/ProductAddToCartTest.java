 package Tests;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;

import org.testng.annotations.Test;

import com.Base.BaseClass;
import com.PageObjects.ProductAddToCart;


import utils.ExtentReports.ExtentTestManager;


public class ProductAddToCartTest extends BaseClass {
	
	private Logger log = Logger.getLogger(ProductAddToCartTest.class.getName());
	
	@Test(priority = 1, description = "Product selection,add to cart")
    public void ProductSelectionTest(Method method) throws Exception {
 
		ProductAddToCart productaddtocart= new ProductAddToCart();
				
        ExtentTestManager.startTest(method.getName(), "Product selection,add to cart");
        
        
        log.info("Trying to login in application");
		LoginTest.loginToApplication();
		log.info("Logged in Successfully");
		log.info("Trying to search products ");
		productaddtocart.goToProductSelectionPage();
             
        productaddtocart.AddToCart();
    //    productaddtocart.RemoveItems();
       }

}
