 package Tests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.Base.BaseClass;
import com.PageObjects.Login;

import utils.ExtentReports.ExtentTestManager;

public class LoginTest extends BaseClass {

	private static Logger log = Logger.getLogger(LoginTest.class.getName());

	@Test(groups = "Login")
	public static void loginToApplication() throws InterruptedException {
		//ExtentTestManager.startTest("loginToApplication", " Login Scenario with valid username and password.");

		new Login().loginToApp(prop.getProperty("username"), prop.getProperty("password"));

		if (driver.getPageSource().contains("Logout")) {
			Assert.assertTrue(true, "Valid user login");
			log.info("Succcessfully login to application with user :" + (prop.getProperty("username")));
		}

	}
}
